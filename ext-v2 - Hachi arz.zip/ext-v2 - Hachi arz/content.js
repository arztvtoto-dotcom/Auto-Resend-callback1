// content.js v2.1
// Fix: Reference No dibaca dari kolom pertama tabel (bukan data-row-key UUID)
// Fix: Next page tidak loop ke page 1, deteksi perubahan tabel via waitForTableChange
// Fix: Unlimited pages dengan logic yang benar

(function () {
  'use strict';

  if (window.__rcProRunning) {
    console.log('[RCPro] Already running, skip re-init');
    return;
  }
  window.__rcProLoaded = true;

  // ── State ────────────────────────────────────────────────────
  let stopRequested = false;
  let stats = { total: 0, success: 0, failed: 0, page: 0 };
  let successList = [];
  let failedList  = [];
  const processedRefs = new Set(); // track semua ref yang sudah diproses di session ini

  const SPEEDS = {
    slow:   { click: 2000, modalOpen: 3500, afterResend: 4000, modalClose: 2000, nextPage: 3500 },
    normal: { click: 1500, modalOpen: 2500, afterResend: 3000, modalClose: 1500, nextPage: 2500 },
    fast:   { click: 800,  modalOpen: 1800, afterResend: 2000, modalClose: 900,  nextPage: 1800 },
  };
  let D = SPEEDS.normal;

  const sleep = ms => new Promise(r => setTimeout(r, ms));

  function nowTs() {
    return new Date().toLocaleTimeString('id-ID', { hour12: false });
  }

  function log(text, level = 'info') {
    console.log(`[RCPro][${level.toUpperCase()}] ${text}`);
    try { chrome.runtime.sendMessage({ type: 'LOG', text, level }); } catch(_) {}
  }

  function sendStats(action = '') {
    try { chrome.runtime.sendMessage({ type: 'STATS', ...stats, action }); } catch(_) {}
  }

  function saveToStorage() {
    chrome.storage.local.set({ successList, failedList, stats });
    try {
      chrome.runtime.sendMessage({ type: 'SUCCESS_LIST', list: successList });
      chrome.runtime.sendMessage({ type: 'FAILED_LIST',  list: failedList  });
    } catch(_) {}
  }

  // ── Wait for element ─────────────────────────────────────────
  function waitForElement(selector, timeout = 8000) {
    return new Promise((resolve, reject) => {
      const el = document.querySelector(selector);
      if (el) return resolve(el);
      const obs = new MutationObserver(() => {
        const found = document.querySelector(selector);
        if (found) { obs.disconnect(); resolve(found); }
      });
      obs.observe(document.body, { childList: true, subtree: true });
      setTimeout(() => { obs.disconnect(); reject(new Error('Timeout: ' + selector)); }, timeout);
    });
  }

  // ── Wait for table to change after next page click ───────────
  // Deteksi perubahan dengan membandingkan konten baris pertama
  function waitForTableChange(prevRef, timeout = 6000) {
    return new Promise((resolve) => {
      const start = Date.now();
      const interval = setInterval(() => {
        const firstRow = document.querySelector('tr.ant-table-row, tr[data-row-key]');
        if (firstRow) {
          const newRef = getReferenceNoFromRow(firstRow);
          if (newRef && newRef !== prevRef && newRef !== 'LOADING') {
            clearInterval(interval);
            log(`  ✓ Tabel berganti: "${prevRef}" → "${newRef}"`);
            resolve(true);
            return;
          }
        }
        if (Date.now() - start > timeout) {
          clearInterval(interval);
          log(`  ⚠ Timeout menunggu tabel berganti`, 'warn');
          resolve(false);
        }
      }, 300);
    });
  }

  // ══════════════════════════════════════════════════════════════
  // GET REFERENCE NO — Baca dari kolom "Reference No." (kolom pertama)
  // Berdasarkan screenshot: Reference No. = "Minera142238641772..."
  // ══════════════════════════════════════════════════════════════
  function getReferenceNoFromRow(row) {
    const cells = row.querySelectorAll('td.ant-table-cell');

    for (const cell of cells) {
      const text = cell.textContent.trim();

      // Ciri Reference No:
      // - Panjang > 10
      // - Tidak ada spasi
      // - Tidak diawali Rp
      // - Tidak berformat tanggal (dd/mm/yyyy)
      // - Tidak hanya angka
      // - Tidak "-"
      // - Tidak "QRIS"
      // - Tidak diawali "+" atau angka saja
      if (
        text.length > 10 &&
        !text.includes(' ') &&
        text !== '-' &&
        !/^Rp/i.test(text) &&
        !/^\d{2}\/\d{2}\/\d{4}/.test(text) &&
        !/^QRIS$/i.test(text) &&
        !/^[+\-]?[\d,]+$/.test(text)
      ) {
        return text;
      }
    }

    // Pola spesifik "Minera" + angka
    for (const cell of cells) {
      const text = cell.textContent.trim();
      if (/^[A-Za-z]{3,}\d{8,}/.test(text)) return text;
    }

    // Last resort: data-row-key (UUID internal)
    const key = row.getAttribute('data-row-key');
    return key || ('REF-' + Date.now());
  }

  // ── Find PENDING rows ────────────────────────────────────────
  function getPendingRows() {
    const seen = new Set();
    const rows = [];

    // Primary: span.ant-tag-orange dengan text "pending"
    document.querySelectorAll('span.ant-tag-orange, span[class*="ant-tag-orange"]').forEach(badge => {
      if (badge.textContent.trim().toLowerCase() === 'pending') {
        const row = badge.closest('tr.ant-table-row, tr[data-row-key], tr[class*="ant-table-row"]');
        if (row && !seen.has(row)) { seen.add(row); rows.push(row); }
      }
    });

    // Fallback
    if (rows.length === 0) {
      document.querySelectorAll('tr.ant-table-row, tr[data-row-key]').forEach(row => {
        for (const sp of row.querySelectorAll('span')) {
          if (sp.textContent.trim().toLowerCase() === 'pending') {
            if (!seen.has(row)) { seen.add(row); rows.push(row); }
            break;
          }
        }
      });
    }

    log(`Found ${rows.length} PENDING rows`);
    return rows;
  }

  // ── Find Details button ──────────────────────────────────────
  function getDetailsBtn(row) {
    for (const btn of row.querySelectorAll('button, a')) {
      const t = (btn.innerText || btn.textContent || '').trim().toLowerCase();
      if (t.includes('detail')) return btn;
    }
    return null;
  }

  // ── Find Resend Callback button ──────────────────────────────
  function getResendBtn() {
    for (const sp of document.querySelectorAll('span')) {
      const t = sp.textContent.trim().toLowerCase();
      if (t === 'resend callback' || t === 'resend') {
        const btn = sp.closest('button') || sp.parentElement;
        if (btn && btn.tagName !== 'SPAN') return btn;
      }
    }
    for (const btn of document.querySelectorAll('button')) {
      const t = (btn.innerText || btn.textContent || '').trim().toLowerCase();
      if (t.includes('resend')) return btn;
    }
    return null;
  }

  // ── Find modal close button ──────────────────────────────────
  function getCloseBtn() {
    const antClose = document.querySelector('button.ant-modal-close, [class*="ant-modal-close"]');
    if (antClose) return antClose;
    for (const btn of document.querySelectorAll('button')) {
      const t   = btn.textContent.trim();
      const cls = btn.className.toLowerCase();
      const lbl = (btn.getAttribute('aria-label') || '').toLowerCase();
      if (t === '×' || t === '✕' || cls.includes('close') || lbl.includes('close')) return btn;
    }
    return null;
  }

  // ── Find visible modal ───────────────────────────────────────
  function findModal() {
    for (const sel of ['.ant-modal-content', '[class*="ant-modal-content"]', '[role="dialog"]']) {
      for (const el of document.querySelectorAll(sel)) {
        const s = window.getComputedStyle(el);
        if (s.display !== 'none' && s.visibility !== 'hidden' && el.offsetHeight > 0) return el;
      }
    }
    return null;
  }

  // ══════════════════════════════════════════════════════════════
  // FIND NEXT PAGE — Ant Design pagination
  // Dari DevTools screenshot: li.ant-pagination-next > button[aria-label="right Next"]
  // ══════════════════════════════════════════════════════════════
  function findNextBtn() {
    // Metode 1: li.ant-pagination-next (paling reliabel)
    const liNext = document.querySelector('li.ant-pagination-next');
    if (liNext) {
      const isDisabled =
        liNext.classList.contains('ant-pagination-disabled') ||
        liNext.getAttribute('aria-disabled') === 'true';

      if (isDisabled) {
        log('⛔ li.ant-pagination-next DISABLED — halaman terakhir', 'info');
        return null;
      }

      // Button di dalam li
      const innerBtn = liNext.querySelector('button');
      if (innerBtn && !innerBtn.disabled) {
        log(`  ✓ Next button: li.ant-pagination-next > button`);
        return innerBtn;
      }

      // Klik li langsung jika tidak ada button
      log(`  ✓ Next: klik li.ant-pagination-next langsung`);
      return liNext;
    }

    // Metode 2: button dengan aria-label mengandung "next"
    for (const btn of document.querySelectorAll('button')) {
      const lbl = (btn.getAttribute('aria-label') || '').toLowerCase();
      if (lbl.includes('next') && !btn.disabled) {
        log(`  ✓ Next button via aria-label: "${btn.getAttribute('aria-label')}"`);
        return btn;
      }
    }

    // Metode 3: span dengan teks "Next" → parent button/li
    for (const sp of document.querySelectorAll('span')) {
      if (sp.textContent.trim() === 'Next') {
        const btn = sp.closest('button') || sp.closest('li');
        if (btn) {
          const dis =
            btn.disabled ||
            btn.classList.contains('disabled') ||
            btn.classList.contains('ant-pagination-disabled');
          if (!dis) {
            log(`  ✓ Next button via span "Next"`);
            return btn;
          }
        }
      }
    }

    log('  ⚠ Next button tidak ditemukan', 'warn');
    return null;
  }

  // ── Get current page number from pagination ──────────────────
  function getCurrentPageNum() {
    const active = document.querySelector(
      'li.ant-pagination-item-active, .ant-pagination-item-active'
    );
    if (active) {
      const n = parseInt(active.textContent.trim() || active.getAttribute('title') || '0');
      return isNaN(n) ? 0 : n;
    }
    return 0;
  }

  // ── Check ref still PENDING ──────────────────────────────────
  function isStillPending(refNo) {
    for (const row of getPendingRows()) {
      if (getReferenceNoFromRow(row) === refNo) return true;
    }
    return false;
  }

  // ── Check if ref already processed ─────────────────────────
  function alreadyProcessed(refNo) {
    // Cek di session tracker (paling cepat)
    if (processedRefs.has(refNo)) {
      const inSuccess = successList.some(i => (typeof i === 'object' ? i.ref : i) === refNo);
      return inSuccess ? 'SUCCESS' : 'FAILED';
    }
    // Cek di persistent storage lists
    const inSuccess = successList.some(i => (typeof i === 'object' ? i.ref : i) === refNo);
    const inFailed  = failedList.some(i  => (typeof i === 'object' ? i.ref : i) === refNo);
    if (inSuccess) return 'SUCCESS';
    if (inFailed)  return 'FAILED';
    return null;
  }

  // ── Process single row ───────────────────────────────────────
  async function processRow(row, idx, total) {
    if (stopRequested) return;

    const refNo   = getReferenceNoFromRow(row);
    const timeNow = nowTs();

    // ── SKIP jika Reference No sudah pernah diproses ──
    const prevStatus = alreadyProcessed(refNo);
    if (prevStatus) {
      log(`⏭ SKIP [${idx+1}/${total}] "${refNo}" — sudah diproses (${prevStatus})`, 'warn');
      sendStats(`SKIP: ${refNo} [${prevStatus}]`);
      try {
        chrome.runtime.sendMessage({ type: 'DUPLICATE_WARN', ref: refNo, prevStatus });
      } catch(_) {}
      return; // tidak proses ulang
    }

    log(`[${idx + 1}/${total}] Ref: ${refNo}`, 'info');
    sendStats(`Memproses: ${refNo}`);

    // 1. Klik Details
    const detBtn = getDetailsBtn(row);
    if (!detBtn) {
      log(`⚠ Details button tidak ada: ${refNo}`, 'warn');
      failedList.push({ ref: refNo, ts: timeNow });
      stats.failed++; stats.total++;
      saveToStorage(); sendStats(); return;
    }
    log(`  → Klik Details`);
    detBtn.click();
    await sleep(D.click);

    // 2. Tunggu modal
    let modal = null;
    try {
      await waitForElement('.ant-modal-content, [class*="ant-modal-content"], [role="dialog"]', 8000);
      modal = findModal();
    } catch(e) {
      log(`⚠ Modal timeout: ${e.message}`, 'warn');
    }
    if (!modal) { await sleep(1000); modal = findModal(); }
    if (!modal) {
      log(`✗ Modal gagal: ${refNo}`, 'error');
      failedList.push({ ref: refNo, ts: timeNow });
      stats.failed++; stats.total++;
      saveToStorage(); sendStats(); return;
    }

    log(`  ✓ Modal terbuka`);
    await sleep(D.modalOpen);

    // 3. Klik Resend Callback
    const resendBtn = getResendBtn();
    if (!resendBtn) {
      log(`⚠ Resend Callback tidak ada: ${refNo}`, 'warn');
      const cb = getCloseBtn(); if (cb) cb.click();
      await sleep(D.modalClose);
      failedList.push({ ref: refNo, ts: timeNow });
      stats.failed++; stats.total++;
      saveToStorage(); sendStats(); return;
    }
    log(`  → Klik Resend Callback`);
    resendBtn.click();
    sendStats(`Resend: ${refNo}`);
    await sleep(D.afterResend);

    // 4. Tutup modal
    const closeBtn = getCloseBtn();
    if (closeBtn) {
      log(`  → Tutup modal`);
      closeBtn.click();
    } else {
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true }));
    }
    await sleep(D.modalClose);

    // 5. Cek hasil
    stats.total++;
    if (!isStillPending(refNo)) {
      log(`  ✅ SUCCESS: ${refNo}`, 'success');
      successList.push({ ref: refNo, ts: timeNow });
      stats.success++;
    } else {
      log(`  ❌ FAILED: ${refNo} masih PENDING`, 'warn');
      failedList.push({ ref: refNo, ts: timeNow });
      stats.failed++;
    }
    processedRefs.add(refNo); // tandai sudah diproses di session ini
    saveToStorage();
    sendStats();
    await sleep(500);
  }

  // ══════════════════════════════════════════════════════════════
  // MAIN LOOP — tidak pernah kembali ke page 1
  // Hanya maju ke depan, berhenti jika next disabled atau 3x kosong
  // ══════════════════════════════════════════════════════════════
  async function mainLoop(speed = 'normal') {
    D = SPEEDS[speed] || SPEEDS.normal;
    window.__rcProRunning = true;

    log(`═══ RCPro v2.1 START — Speed: ${speed} ═══`, 'info');

    const saved = await chrome.storage.local.get(['successList', 'failedList', 'stats']);
    successList = saved.successList || [];
    failedList  = saved.failedList  || [];
    stats       = saved.stats       || { total: 0, success: 0, failed: 0, page: 0 };
    stats.page  = 0;

    let pageNum = 1;
    let emptyStreak = 0; // halaman kosong berturut-turut

    while (true) {
      if (stopRequested) {
        log('■ Stop by user', 'warn');
        chrome.runtime.sendMessage({ type: 'STOPPED' });
        window.__rcProRunning = false;
        return;
      }

      stats.page = pageNum;
      sendStats(`Scanning halaman ${pageNum}...`);
      log(`──── Halaman ${pageNum} (pagination: ${getCurrentPageNum()}) ────`);
      await sleep(1000);

      const pendingRows = getPendingRows();

      // ── Tidak ada PENDING di halaman ini ──
      if (pendingRows.length === 0) {
        emptyStreak++;
        log(`  Kosong (streak: ${emptyStreak})`);

        // Setelah 3 halaman kosong berturut-turut, anggap selesai
        if (emptyStreak >= 3) {
          log('✓ 3 halaman kosong — semua PENDING selesai!', 'success');
          break;
        }

        // Coba next page
        const nextBtn = findNextBtn();
        if (!nextBtn) {
          log('✓ Next page tidak ada — selesai!', 'success');
          break;
        }

        // Simpan ref baris pertama untuk detect perubahan
        const firstRow = document.querySelector('tr.ant-table-row, tr[data-row-key]');
        const refBefore = firstRow ? getReferenceNoFromRow(firstRow) : null;
        log(`  Ref baris pertama sebelum next: "${refBefore}"`);

        log(`  → Next page...`);
        nextBtn.click();
        pageNum++;

        // Tunggu tabel berubah
        if (refBefore) {
          const changed = await waitForTableChange(refBefore, 6000);
          if (!changed) await sleep(D.nextPage);
        } else {
          await sleep(D.nextPage);
        }
        await sleep(300);
        continue;
      }

      // ── Ada PENDING — reset streak ──
      emptyStreak = 0;

      // Cek apakah SEMUA baris di halaman ini sudah pernah diproses
      // Jika iya, berarti next page tidak berfungsi dan kita loop ke halaman yang sama
      const allAlreadyDone = pendingRows.every(row => {
        const ref = getReferenceNoFromRow(row);
        return alreadyProcessed(ref) !== null;
      });

      if (allAlreadyDone) {
        log(`⚠⚠ PERINGATAN: Semua ${pendingRows.length} baris di halaman ${pageNum} sudah diproses sebelumnya!`, 'error');
        log(`⚠⚠ KEMUNGKINAN NEXT PAGE TIDAK BERFUNGSI — halaman tidak berganti`, 'error');
        try {
          chrome.runtime.sendMessage({
            type: 'PAGE_LOOP_WARN',
            pageNum,
            refs: pendingRows.map(r => getReferenceNoFromRow(r))
          });
        } catch(_) {}

        // Paksa coba next page lagi
        const nextBtn = findNextBtn();
        if (!nextBtn) {
          log('Tidak ada next page, proses selesai', 'success');
          break;
        }
        const firstRow = document.querySelector('tr.ant-table-row, tr[data-row-key]');
        const refBefore = firstRow ? getReferenceNoFromRow(firstRow) : null;
        log(`  Paksa klik next page (ref sebelum: "${refBefore}")...`, 'warn');
        nextBtn.click();
        pageNum++;
        if (refBefore) {
          await waitForTableChange(refBefore, 6000);
        } else {
          await sleep(D.nextPage);
        }
        await sleep(500);
        continue;
      }

      const reversed = Array.from(pendingRows).reverse();
      log(`  Memproses ${reversed.length} baris (bawah→atas)...`);

      for (let i = 0; i < reversed.length; i++) {
        if (stopRequested) {
          chrome.runtime.sendMessage({ type: 'STOPPED' });
          window.__rcProRunning = false;
          return;
        }
        await processRow(reversed[i], i, reversed.length);
        await sleep(D.click);
      }

      // ── Setelah semua baris diproses, lanjut ke next page ──
      await sleep(1500);
      log(`  Selesai halaman ${pageNum} — cek next page...`);

      const nextBtn = findNextBtn();
      if (!nextBtn) {
        log('✓ Next page tidak ada — selesai!', 'success');
        break;
      }

      const firstRow = document.querySelector('tr.ant-table-row, tr[data-row-key]');
      const refBefore = firstRow ? getReferenceNoFromRow(firstRow) : null;
      log(`  Ref baris pertama sebelum next: "${refBefore}"`);

      log(`  → Pindah ke halaman ${pageNum + 1}...`);
      nextBtn.click();
      pageNum++;

      if (refBefore) {
        const changed = await waitForTableChange(refBefore, 6000);
        if (!changed) await sleep(D.nextPage);
      } else {
        await sleep(D.nextPage);
      }
      await sleep(300);
    }

    log('═══ SEMUA SELESAI ═══', 'success');
    sendStats('Selesai');
    window.__rcProRunning = false;

    try {
      chrome.runtime.sendMessage({
        type: 'DONE',
        successCount: stats.success,
        failedCount:  stats.failed
      });
    } catch(_) {}
  }

  // ── Message listener ─────────────────────────────────────────
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'START') {
      if (window.__rcProRunning) {
        log('⚠ Sudah berjalan', 'warn');
        sendResponse({ ok: false });
        return true;
      }
      stopRequested = false;
      mainLoop(msg.speed || 'normal').catch(err => {
        console.error('[RCPro] Fatal:', err);
        log(`Fatal: ${err.message}`, 'error');
        window.__rcProRunning = false;
        try { chrome.runtime.sendMessage({ type: 'ERROR', text: err.message }); } catch(_) {}
        try { chrome.runtime.sendMessage({ type: 'STOPPED' }); } catch(_) {}
      });
      sendResponse({ ok: true });
    }
    if (msg.type === 'STOP') {
      stopRequested = true;
      log('■ Stop requested', 'warn');
      sendResponse({ ok: true });
    }
    return true;
  });

  console.log('[RCPro] content.js v2.1 loaded ✓');
})();
