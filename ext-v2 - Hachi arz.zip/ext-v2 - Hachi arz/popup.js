// popup.js v2.0 — Premium UI logic

'use strict';

let isRunning = false;
let logCount  = 0;
let elapsedTimer = null;
let elapsedSec   = 0;
let currentSpeed = 'normal';

// ── DOM ──────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);
const btnStart    = $('btnStart');
const btnStop     = $('btnStop');
const btnClear    = $('btnClear');
const btnExport   = $('btnExport');
const statusDot   = $('statusDot');
const statusText  = $('statusText');
const statusAction= $('statusAction');
const elapsedVal  = $('elapsedVal');
const progressFill= $('progressFill');
const progressPct = $('progressPct');
const statTotal   = $('statTotal');
const statPage    = $('statPage');
const statSuccess = $('statSuccess');
const statFailed  = $('statFailed');
const tabLog      = $('tabLog');
const tabSuccess  = $('tabSuccess');
const tabFailed   = $('tabFailed');
const badgeLog    = $('badgeLog');
const badgeSuccess= $('badgeSuccess');
const badgeFailed = $('badgeFailed');
const doneBanner  = $('doneBanner');
const doneSucess  = $('doneSucess');
const doneFailed2 = $('doneFailed');
const doneBannerSub=$('doneBannerSub');
const footerSpeed = $('footerSpeed');

// ── Elapsed Timer ─────────────────────────────────────────────
function startTimer() {
  elapsedSec = 0;
  clearInterval(elapsedTimer);
  elapsedTimer = setInterval(() => {
    elapsedSec++;
    const m = String(Math.floor(elapsedSec / 60)).padStart(2, '0');
    const s = String(elapsedSec % 60).padStart(2, '0');
    elapsedVal.textContent = `${m}:${s}`;
  }, 1000);
}
function stopTimer() { clearInterval(elapsedTimer); }

// ── Status ────────────────────────────────────────────────────
function setStatus(text, action = '', dotClass = '') {
  statusText.textContent   = text;
  statusAction.textContent = action;
  statusDot.className      = 'status-dot ' + dotClass;
}

// ── Progress ──────────────────────────────────────────────────
function setProgress(success, failed, total) {
  const done = success + failed;
  const pct  = total > 0 ? Math.min(100, Math.round((done / total) * 100)) : 0;
  progressFill.style.width = pct + '%';
  progressPct.textContent  = pct + '%';
}

// ── Log ───────────────────────────────────────────────────────
function addLog(msg, type = 'info') {
  const empty = tabLog.querySelector('.empty');
  if (empty) empty.remove();
  logCount++;
  badgeLog.textContent = logCount;
  const row = document.createElement('div');
  row.className = `log-row ${type}`;
  const now = new Date();
  const ts  = now.toLocaleTimeString('id-ID', { hour12: false });
  row.innerHTML = `<span class="log-ts">${ts}</span><span class="log-msg">${escHtml(msg)}</span>`;
  tabLog.appendChild(row);
  tabLog.scrollTop = tabLog.scrollHeight;
}

function escHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// ── Render ref list ──────────────────────────────────────────
function renderList(containerId, badgeEl, items, cls) {
  const c = $(containerId);
  c.innerHTML = '';
  if (!items || items.length === 0) {
    c.innerHTML = `<div class="empty"><div class="empty-icon">${cls==='success'?'⏳':'⏳'}</div><div class="empty-text">Belum ada data</div></div>`;
    badgeEl.textContent = 0;
    return;
  }
  badgeEl.textContent = items.length;
  items.forEach((item, idx) => {
    const row = document.createElement('div');
    row.className = `ref-row ${cls}`;
    const icon = cls === 'success' ? '✅' : '❌';
    const ref  = typeof item === 'object' ? item.ref : item;
    const ts   = typeof item === 'object' ? item.ts  : '';
    row.innerHTML = `
      <span class="ref-icon">${icon}</span>
      <span class="ref-text">${escHtml(ref)}</span>
      <span class="ref-num">#${idx + 1}${ts ? ' · ' + ts : ''}</span>
    `;
    c.appendChild(row);
  });
}

// ── Tabs ─────────────────────────────────────────────────────
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    tab.classList.add('active');
    $(tab.dataset.tab).classList.add('active');
  });
});

// ── Speed selector ────────────────────────────────────────────
document.querySelectorAll('.speed-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    if (isRunning) return;
    document.querySelectorAll('.speed-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentSpeed = btn.dataset.speed;
    const labels = { slow: 'Slow Speed', normal: 'Normal Speed', fast: 'Fast Speed' };
    footerSpeed.textContent = labels[currentSpeed];
    chrome.storage.local.set({ speed: currentSpeed });
  });
});

// ── Load saved data ───────────────────────────────────────────
async function loadSaved() {
  const data = await chrome.storage.local.get(['successList','failedList','stats','speed']);
  const sl   = data.successList || [];
  const fl   = data.failedList  || [];
  const st   = data.stats       || { total:0, success:0, failed:0, page:0 };
  const sp   = data.speed       || 'normal';

  statTotal.textContent   = st.total;
  statPage.textContent    = st.page;
  statSuccess.textContent = st.success;
  statFailed.textContent  = st.failed;
  setProgress(st.success, st.failed, st.total);
  renderList('tabSuccess', badgeSuccess, sl, 'success');
  renderList('tabFailed',  badgeFailed,  fl, 'failed');

  // Restore speed
  currentSpeed = sp;
  document.querySelectorAll('.speed-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.speed === sp);
  });
  const labels = { slow: 'Slow Speed', normal: 'Normal Speed', fast: 'Fast Speed' };
  footerSpeed.textContent = labels[sp];
}
loadSaved();

// ── Messages from content script ─────────────────────────────
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'LOG') {
    addLog(msg.text, msg.level || 'info');
  }
  if (msg.type === 'STATS') {
    statTotal.textContent   = msg.total;
    statPage.textContent    = msg.page;
    statSuccess.textContent = msg.success;
    statFailed.textContent  = msg.failed;
    if (msg.action) statusAction.textContent = msg.action;
    setProgress(msg.success, msg.failed, msg.total);
  }
  if (msg.type === 'SUCCESS_LIST') {
    renderList('tabSuccess', badgeSuccess, msg.list, 'success');
  }
  if (msg.type === 'FAILED_LIST') {
    renderList('tabFailed', badgeFailed, msg.list, 'failed');
  }
  if (msg.type === 'DONE') {
    isRunning = false;
    stopTimer();
    setStatus('Selesai ✓', 'Semua transaksi PENDING telah diproses', 'done');
    btnStart.disabled = false;
    btnStop.disabled  = true;
    progressFill.style.width = '100%';
    progressPct.textContent  = '100%';
    addLog('═══ SEMUA PROSES SELESAI ═══', 'success');
    // Show banner
    const sl = msg.successCount || 0;
    const fl = msg.failedCount  || 0;
    doneSucess.textContent  = sl;
    doneFailed2.textContent = fl;
    doneBannerSub.textContent = `Waktu: ${elapsedVal.textContent} · ${sl + fl} total diproses`;
    doneBanner.classList.add('show');
    // Browser notification
    chrome.notifications && chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icons/icon48.png',
      title: 'Resend Callback Selesai!',
      message: `✅ ${sl} berhasil · ❌ ${fl} gagal`
    });
  }
  if (msg.type === 'STOPPED') {
    isRunning = false;
    stopTimer();
    setStatus('Dihentikan', 'Proses dihentikan oleh pengguna', 'stopped');
    btnStart.disabled = false;
    btnStop.disabled  = true;
    addLog('■ Proses dihentikan', 'warn');
  }
  if (msg.type === 'ERROR') {
    addLog('ERROR: ' + msg.text, 'error');
  }
  // ── Duplicate skip warning ──
  if (msg.type === 'DUPLICATE_WARN') {
    addLog(`⏭ SKIP: "${msg.ref}" sudah diproses sebelumnya [${msg.prevStatus}] — tidak diproses ulang`, 'warn');
  }
  // ── Page loop warning: next page tidak berfungsi ──
  if (msg.type === 'PAGE_LOOP_WARN') {
    addLog(`⚠⚠ LOOP DETECTED halaman ${msg.pageNum}: ${msg.refs.length} ref sudah diproses semua!`, 'error');
    addLog(`⚠⚠ Next page mungkin tidak berfungsi — cek pagination dashboard`, 'error');
    // Flash the status bar merah
    statusDot.className = 'status-dot stopped';
    statusText.textContent = `⚠ Loop detected pg.${msg.pageNum}`;
    setTimeout(() => {
      if (isRunning) {
        statusDot.className = 'status-dot running';
        statusText.textContent = 'Running...';
      }
    }, 3000);
  }
});

// ── START ─────────────────────────────────────────────────────
btnStart.addEventListener('click', async () => {
  if (isRunning) return;
  isRunning = true;
  doneBanner.classList.remove('show');
  setStatus('Running...', 'Menginisialisasi...', 'running');
  btnStart.disabled = true;
  btnStop.disabled  = false;
  startTimer();
  addLog('▶ Memulai proses — Speed: ' + currentSpeed, 'info');

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.tabs.sendMessage(tab.id, { type: 'START', speed: currentSpeed });
});

// ── STOP ──────────────────────────────────────────────────────
btnStop.addEventListener('click', async () => {
  if (!isRunning) return;
  addLog('■ Mengirim perintah STOP...', 'warn');
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.tabs.sendMessage(tab.id, { type: 'STOP' });
});

// ── EXPORT CSV ────────────────────────────────────────────────
btnExport.addEventListener('click', async () => {
  const data = await chrome.storage.local.get(['successList', 'failedList', 'stats']);
  const sl   = data.successList || [];
  const fl   = data.failedList  || [];
  const st   = data.stats       || {};

  let csv = 'Reference No,Status,Timestamp\n';
  sl.forEach(item => {
    const ref = typeof item === 'object' ? item.ref : item;
    const ts  = typeof item === 'object' ? item.ts  : '';
    csv += `"${ref}","SUCCESS","${ts}"\n`;
  });
  fl.forEach(item => {
    const ref = typeof item === 'object' ? item.ref : item;
    const ts  = typeof item === 'object' ? item.ts  : '';
    csv += `"${ref}","FAILED","${ts}"\n`;
  });

  const blob = new Blob([csv], { type: 'text/csv' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  const now  = new Date().toISOString().slice(0,16).replace('T','_').replace(':','-');
  a.href     = url;
  a.download = `resend_callback_${now}.csv`;
  a.click();
  URL.revokeObjectURL(url);
  addLog('📥 Data diekspor ke CSV', 'info');
});

// ── CLEAR ─────────────────────────────────────────────────────
btnClear.addEventListener('click', async () => {
  if (isRunning) { addLog('⚠ Hentikan proses sebelum clear data', 'warn'); return; }
  if (!confirm('Hapus semua data success & failed?')) return;
  await chrome.storage.local.clear();
  statTotal.textContent = statPage.textContent = statSuccess.textContent = statFailed.textContent = '0';
  progressFill.style.width = '0%';
  progressPct.textContent  = '0%';
  logCount = 0;
  badgeLog.textContent = 0;
  tabLog.innerHTML = '<div class="empty"><div class="empty-icon">📋</div><div class="empty-text">Log dibersihkan</div></div>';
  renderList('tabSuccess', badgeSuccess, [], 'success');
  renderList('tabFailed',  badgeFailed,  [], 'failed');
  doneBanner.classList.remove('show');
  setStatus('Idle — Ready', 'Data dibersihkan', '');
  elapsedVal.textContent = '00:00';
  addLog('🗑 Data cleared', 'warn');
});
