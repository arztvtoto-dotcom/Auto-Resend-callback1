// background.js v2.0
chrome.runtime.onInstalled.addListener(() => {
  console.log('[RCPro] Extension installed v2.0');
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'KEEPALIVE') sendResponse({ alive: true });
  return true;
});
